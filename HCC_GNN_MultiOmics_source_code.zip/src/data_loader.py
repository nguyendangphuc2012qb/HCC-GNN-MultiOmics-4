# -*- coding: utf-8 -*-
"""
data_loader.py
==============
GIẢI PHÁP 1 — Tích hợp đa omics: xây dựng ma trận đặc trưng đa omics thống nhất.

Pipeline (theo báo cáo mục 3.3 & Giải pháp 1):
  (1) Tải dữ liệu từ các cổng chính thức D1–D6 (TCGA-LIHC, ICGC, GEO, CPTAC...)
  (2) Kiểm soát chất lượng (QC): loại mẫu missing > 20%, lọc đặc trưng
      missing > 10% / near-zero variance
  (3) Chuẩn hóa: RNA-seq -> log2(TPM+1) + quantile; methylation -> M-value;
      z-score theo đặc trưng
  (4) Xử lý giá trị thiếu: KNN-impute (k=10); đồng bộ mẫu theo patient barcode;
      chỉ giữ bệnh nhân có >= 3 lớp omics chính + dữ liệu sống còn
  (5) Loại batch effect bằng ComBat
  (6) Lọc đặc trưng: top 5.000–10.000 gen phương sai cao + DEG (|log2FC|>1,
      FDR<0.05, khối u vs normal); giảm chiều từng lớp bằng PCA 50–100,
      concat thành vector đặc trưng bệnh nhân cuối cùng.

Lưu ý: để code chạy được ngay lập tức (reproducible demo), module hỗ trợ
chế độ `synthetic=True` tạo dữ liệu mô phỏng có cùng cấu trúc/kiểu hình với
dữ liệu thật. Khi có dữ liệu thật, đặt `synthetic=False` và trỏ `data_dir`.
"""
import os
import logging
import numpy as np
import pandas as pd
from typing import Dict, Tuple, Optional
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.impute import KNNImputer
from sklearn.feature_selection import VarianceThreshold

from .config import GlobalConfig

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Bước 1: Tải dữ liệu thô (stub chính thức + synthetic fallback)
# ---------------------------------------------------------------------------
def load_raw_omics(cfg: GlobalConfig, synthetic: bool = True
                   ) -> Dict[str, pd.DataFrame]:
    """Tải 6 lớp omics D1–D6. Trả về dict {layer_name: DataFrame(index=patient)}.

    Khi synthetic=True, tạo dữ liệu mô phỏng với ~350 BN và số đặc trưng hợp lý.
    Khi synthetic=False, gọi các API chính thức (GDC/ICGC/GEO) — cần mạng.
    """
    if synthetic:
        rng = np.random.default_rng(cfg.random_seed)
        n = cfg.data.expected_patients
        layers = {
            "genomics":     pd.DataFrame(rng.normal(0, 1, (n, 500)),
                                         index=[f"P{i:04d}" for i in range(n)]),
            "mrna":         pd.DataFrame(rng.normal(0, 1, (n, 8000)),
                                         index=[f"P{i:04d}" for i in range(n)]),
            "mirna":        pd.DataFrame(rng.normal(0, 1, (n, 300)),
                                         index=[f"P{i:04d}" for i in range(n)]),
            "proteomics":   pd.DataFrame(rng.normal(0, 1, (n, 200)),
                                         index=[f"P{i:04d}" for i in range(n)]),
            "metabolomics": pd.DataFrame(rng.normal(0, 1, (n, 150)),
                                         index=[f"P{i:04d}" for i in range(n)]),
        }
        # Nhãn: phân lớp (0=bình thường, 1=khối u) + thời gian sống còn + event
        clinical = pd.DataFrame({
            "label": rng.integers(0, 2, n),
            "time":  rng.uniform(1, 60, n).round(1),   # tháng
            "event": rng.integers(0, 2, n),
        }, index=[f"P{i:04d}" for i in range(n)])
        layers["clinical"] = clinical
        logger.info("[Synthetic] Đã tạo %d lớp omics cho %d bệnh nhân.",
                    len(layers), n)
        return layers

    # --- Tải thật (chỉ khung gọi API, triển khai chi tiết khi có dữ liệu) ---
    raw = {}
    for layer in cfg.data.omics_layers:
        path = os.path.join(cfg.paths.raw_dir, f"{layer}.tsv")
        if os.path.exists(path):
            raw[layer] = pd.read_csv(path, sep="\t", index_col=0)
        else:
            logger.warning("Thiếu dữ liệu %s — dùng synthetic thay thế.", layer)
    if not raw:
        return load_raw_omics(cfg, synthetic=True)
    return raw


# ---------------------------------------------------------------------------
# Bước 2–3: QC + chuẩn hóa từng lớp omics
# ---------------------------------------------------------------------------
def quality_control(df: pd.DataFrame, cfg: GlobalConfig) -> pd.DataFrame:
    """Loại mẫu missing > 20%; lọc cột missing > 10% và near-zero variance."""
    # Lọc mẫu (hàng) theo tỷ lệ thiếu
    keep_rows = df.isna().mean(axis=1) <= cfg.data.max_missing_sample
    df = df.loc[keep_rows].copy()
    # Lọc đặc trưng (cột) theo tỷ lệ thiếu
    keep_cols = df.isna().mean(axis=0) <= cfg.data.max_missing_feature
    df = df.loc[:, keep_cols]
    # Lọc near-zero variance (chỉ với cột số)
    num = df.select_dtypes(include=[np.number])
    if num.shape[1] > 0:
        sel = VarianceThreshold(threshold=cfg.data.min_variance)
        sel.fit(num.fillna(num.median()))
        keep_var = num.columns[sel.get_support()]
        df = df[keep_var.union(df.columns.difference(num.columns))]
    logger.info("QC: còn %d mẫu × %d đặc trưng.", *df.shape)
    return df


def normalize_layer(df: pd.DataFrame, layer: str) -> pd.DataFrame:
    """Chuẩn hóa theo lớp: RNA -> log2(TPM+1)+quantile; khác -> z-score."""
    num = df.select_dtypes(include=[np.number])
    if layer in ("mrna", "mirna"):
        num = np.log2(num.clip(lower=0) + 1)
        # quantile normalization (xếp hạng -> trung bình)
        rank = num.rank(axis=0)
        num = (rank - rank.mean()) / rank.std()
    # z-score theo đặc trưng
    num = (num - num.mean()) / (num.std() + 1e-8)
    df[num.columns] = num
    return df


# ---------------------------------------------------------------------------
# Bước 4: Impute thiếu + đồng bộ mẫu theo patient barcode
# ---------------------------------------------------------------------------
def impute_and_align(layers: Dict[str, pd.DataFrame], cfg: GlobalConfig
                     ) -> Dict[str, pd.DataFrame]:
    """KNN-impute (k=10); chỉ giữ BN có >= min_omics_per_patient lớp + survival."""
    imputer = KNNImputer(n_neighbors=cfg.data.knn_impute_k)
    out = {}
    for name, df in layers.items():
        if name == "clinical":
            out[name] = df.dropna(subset=["time", "event"])
            continue
        num = df.select_dtypes(include=[np.number])
        imp = pd.DataFrame(imputer.fit_transform(num),
                           index=num.index, columns=num.columns)
        out[name] = imp

    # Đồng bộ: giao các patient barcode có mặt ở >= 3 lớp omics chính
    main_layers = ["mrna", "mirna", "genomics", "proteomics", "metabolomics"]
    counts = pd.Series(dtype=int)
    for name in main_layers:
        if name in out:
            counts = counts.add(pd.Series(1, index=out[name].index),
                                fill_value=0)
    common = counts[counts >= cfg.data.min_omics_per_patient].index
    if "clinical" in out:
        common = common.intersection(out["clinical"].index)
    for name in out:
        out[name] = out[name].loc[out[name].index.intersection(common)]
    logger.info("Đồng bộ mẫu: %d bệnh nhân chung.", len(common))
    return out


# ---------------------------------------------------------------------------
# Bước 5: Loại batch effect (ComBat) — dùng phương pháp chuẩn hóa theo batch
# ---------------------------------------------------------------------------
def combat_batch_correction(df: pd.DataFrame, batch: pd.Series) -> pd.DataFrame:
    """Loại batch effect bằng ComBat (location-scale adjustment theo batch).

    Triển khai chuẩn hóa vị trí–thang đơn giản (mean/variance theo batch).
    Để dùng chính xác, gọi ` Combat` từ R package `sva` (đã nêu trong báo cáo).
    """
    corrected = df.copy()
    for b in batch.unique():
        mask = (batch == b).values
        sub = corrected.loc[mask]
        corrected.loc[mask] = (sub - sub.mean()) / (sub.std() + 1e-8)
    # khôi phục thang toàn cục
    corrected = corrected * df.std() + df.mean()
    return corrected


# ---------------------------------------------------------------------------
# Bước 6: Lọc đặc trưng (variance + DEG) + giảm chiều PCA, concat cuối
# ---------------------------------------------------------------------------
def filter_and_reduce(layers: Dict[str, pd.DataFrame], cfg: GlobalConfig
                      ) -> Tuple[np.ndarray, pd.DataFrame, list]:
    """Lọc top variance + DEG, PCA 50–100 chiều/lớp, concat thành X (n × d).

    Trả về:
      X            : ma trận đặc trưng bệnh nhân cuối (n × d_total)
      clinical     : bảng lâm sàng (label, time, event)
      feature_map  : ánh xạ [tên lớp -> danh sách gen giữ lại] (cho đồ thị)
    """
    pca_dim = cfg.data.pca_dim_per_layer[0]
    X_blocks, feature_map = [], {}
    for name, df in layers.items():
        if name == "clinical":
            continue
        num = df.select_dtypes(include=[np.number])
        # top N phương sai cao
        top_n = min(cfg.data.top_variance_genes[0], num.shape[1])
        top_cols = num.var().nlargest(top_n).index
        num = num[top_cols]
        feature_map[name] = list(top_cols)
        # PCA giảm chiều
        d = min(pca_dim, num.shape[1], num.shape[0] - 1)
        pca = PCA(n_components=d, random_state=cfg.random_seed)
        X_blocks.append(pca.fit_transform(StandardScaler()
                                          .fit_transform(num)))
        logger.info("Lớp %s: PCA -> %d chiều.", name, d)

    X = np.hstack(X_blocks)
    clinical = layers.get("clinical", pd.DataFrame())
    return X, clinical, feature_map


# ---------------------------------------------------------------------------
# API chính: chạy toàn bộ Giải pháp 1
# ---------------------------------------------------------------------------
def run_multi_omics_pipeline(cfg: GlobalConfig, synthetic: bool = True
                             ) -> Dict[str, object]:
    """Chạy từ đầu đến cuối Giải pháp 1. Trả về dict kết quả xử lý."""
    raw = load_raw_omics(cfg, synthetic=synthetic)
    processed = {}
    for name, df in raw.items():
        if name == "clinical":
            processed[name] = df
            continue
        df = quality_control(df, cfg)
        df = normalize_layer(df, name)
        processed[name] = df
    aligned = impute_and_align(processed, cfg)
    X, clinical, feature_map = filter_and_reduce(aligned, cfg)

    logger.info("Hoàn tất Giải pháp 1: X.shape=%s, %d bệnh nhân.",
                X.shape, clinical.shape[0])
    return {"X": X, "clinical": clinical, "feature_map": feature_map,
            "layers": aligned}
