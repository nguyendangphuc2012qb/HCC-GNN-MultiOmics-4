# -*- coding: utf-8 -*-
"""
config.py
=========
Cấu hình tập trung (single source of truth) cho toàn bộ pipeline
HCC-GNN-MultiOmics. Mọi siêu tham số, trọng số hàm mất mát, ngưỡng lọc
và đường dẫn dữ liệu được khai báo tại đây để đảm bảo tái lập
(reproducibility) theo nguyên tắc nghiên cứu khoa học.

Tất cả giá trị dưới đây được trích xuất chính xác từ Báo cáo nghiên cứu
(phần 3.4 Giải pháp 2 và Bảng 4.1).
"""
from dataclasses import dataclass, field
from typing import Dict, List, Tuple


@dataclass
class DataConfig:
    """Cấu hình thu thập & tiền xử lý dữ liệu (Giải pháp 1)."""
    # 7 "điểm dữ liệu" D1-D7 (Bảng 3.1)
    omics_layers: List[str] = field(default_factory=lambda: [
        "genomics",          # D1: SNV/INDEL, CNV, methylation
        "mrna",              # D2: RNA-seq biểu hiện gen
        "mirna",             # D3: biểu hiện miRNA
        "proteomics",        # D4: RPPA/LC-MS, phospho
        "metabolomics",      # D5: chất chuyển hóa
        "clinical",          # D6: TNM/BCLC, OS/RFS, HBV/HCV
    ])
    # Nguồn dữ liệu chính & nhóm xác nhận độc lập
    cohort_main: str = "TCGA-LIHC"            # ~377 BN, đủ 4 lớp omics
    cohorts_external: Tuple[str, ...] = ("ICGC-LIRI-JP", "GSE14520",
                                         "GSE76427", "CPTAC-HCC")
    # Ngưỡng kiểm soát chất lượng (QC)
    max_missing_sample: float = 0.20          # loại mẫu thiếu > 20%
    max_missing_feature: float = 0.10         # lọc đặc trưng thiếu > 10%
    min_variance: float = 1e-4                # near-zero variance filter
    # Chuẩn hóa
    rna_norm: str = "log2_tpm1_quantile"      # log2(TPM+1) + quantile
    methylation_norm: str = "beta_m_value"
    # Đồng bộ mẫu: chỉ giữ BN có >= 3 lớp omics chính + survival
    min_omics_per_patient: int = 3
    # Lọc đặc trưng & giảm chiều
    top_variance_genes: Tuple[int, int] = (5000, 10000)   # top 5k–10k
    deg_threshold: Dict[str, float] = field(default_factory=lambda: {
        "abs_log2fc": 1.0, "fdr": 0.05                    # khối u vs normal
    })
    pca_dim_per_layer: Tuple[int, int] = (50, 100)        # giảm 50–100 chiều
    knn_impute_k: int = 10
    batch_correction: str = "ComBat"
    expected_patients: int = 350                           # sau QC & đồng bộ


@dataclass
class GraphConfig:
    """Cấu hình đồ thị dị thể (Giải pháp 2)."""
    # 5 loại nút (node types)
    node_types: List[str] = field(default_factory=lambda: [
        "gene",          # gen/protein ~5.000–10.000
        "metabolite",    # chất chuyển hóa ~200–500
        "drug",          # thuốc ~2.000–5.000
        "disease",       # bệnh ~50–100
        "patient",       # bệnh nhân ~350
    ])
    # 7 loại cạnh (edge types)
    edge_types: List[Tuple[str, str, str]] = field(default_factory=lambda: [
        ("gene", "ppi", "gene"),                    # PPI: STRING v12
        ("gene", "codes_for", "protein"),           # gen–protein (alias gene)
        ("protein", "regulates", "metabolite"),     # protein–chất chuyển hóa
        ("drug", "targets", "gene"),                # thuốc–đích (DrugBank/ChEMBL)
        ("drug", "interacts", "drug"),              # thuốc–thuốc
        ("patient", "expresses", "gene"),           # bệnh nhân–gen (omics)
        ("disease", "associates", "gene"),          # bệnh–gen (DisGeNET/CTD)
    ])
    string_combined_score_min: int = 700            # PPI combined score ≥ 700
    drugbank_version: str = "5.x"
    chembl_version: str = "33"


@dataclass
class ModelConfig:
    """Cấu hình kiến trúc GNN (HAN + GAT) & hàm mất mát đa nhiệm."""
    # Nhúng nút: 64–256 chiều (theo thuật ngữ chuyên ngành mục 1.2)
    hidden_dim: int = 128
    num_heads: int = 8                     # multi-head attention
    num_layers: int = 3                    # số lớp GNN
    dropout: float = 0.3
    negative_slope: float = 0.2            # LeakyReLU trong GAT
    # Trọng số hàm mất mát đa nhiệm (đúng báo cáo, Giải pháp 2 mục b)
    # Ltotal = λ1·Lcls + λ2·Lreg + λ3·Llink + λ4·||Θ||₂² + λ5·Lrecon
    lambda_cls: float = 1.0
    lambda_reg: float = 1.0
    lambda_link: float = 0.5
    lambda_l2: float = 1e-4
    lambda_recon: float = 0.1
    # Đầu ra đa nhiệm
    num_classes: int = 2                   # phân lớp khối u vs bình thường
    survival_output: int = 1               # Cox risk score
    ic50_output: int = 1                   # hồi quy log IC50
    recon_output: int = 128                # tái tạo đặc trưng đa omics


@dataclass
class TrainConfig:
    """Cấu hình huấn luyện (đúng báo cáo: Adam, cosine annealing...)."""
    optimizer: str = "Adam"
    learning_rate: float = 1e-3
    weight_decay: float = 1e-4
    lr_scheduler: str = "cosine_annealing"
    epochs: int = 500
    early_stopping_patience: int = 50
    batch_sampling: str = "neighbor_sampling"      # mini-batch neighbor sampling
    # Cross-validation: 5-fold, lặp lại 5 lần với seed khác nhau
    n_folds: int = 5
    n_repeats: int = 5
    seeds: Tuple[int, ...] = (42, 123, 2024, 7, 99)
    negative_sampling_ratio: float = 1.0           # link prediction
    mixed_precision: bool = True
    device: str = "cuda"                           # fallback CPU nếu không có GPU


@dataclass
class BiomarkerConfig:
    """Cấu hình xếp hạng biomarker (Giải pháp 3)."""
    # Biomarker Score = 0.35·attention + 0.25·centrality + 0.25·prognostic + 0.15·DEG
    weight_attention: float = 0.35
    weight_centrality: float = 0.25
    weight_prognostic: float = 0.25
    weight_deg: float = 0.15
    centrality_metrics: Tuple[str, ...] = ("degree", "betweenness", "closeness")
    top_n_biomarkers: int = 20
    core_n: int = 5                                # 3–5 phân tử cốt lõi
    expected_core_axis: Tuple[str, ...] = ("PLK1", "CDC20", "BUB1",
                                           "AURKA", "AURKB", "CCNB1")
    survival_cutoff: str = "median"                # chia high/low theo trung vị
    logrank_alpha: float = 0.05


@dataclass
class DrugScreeningConfig:
    """Cấu hình sàng lọc thuốc (Giải pháp 4) — 5 bước."""
    # Bước 1: giữ hợp chất đã có hồ sơ an toàn (FDA-approved / clinical I/II)
    drug_pool_size: int = 10240                    # ~10.240 hợp chất
    # Bước 2: loại trừ thuốc chuẩn HCC hiện hành
    exclude_standard_hcc: Tuple[str, ...] = ("Sorafenib", "Lenvatinib",
                                             "Regorafenib", "Cabozantinib",
                                             "Ramucirumab")
    # Bước 3: Lipinski Rule of Five + ADMET
    lipinski_max_violations: int = 1
    admet_filters: Tuple[str, ...] = ("hepatotoxicity", "renal_toxicity",
                                      "bioavailability")
    # Bước 4: thang điểm kết hợp = Embedding score × P(target cốt lõi) × P(IC50 thấp)
    top_n_after_ranking: int = 50
    # Bước 5: Top 5 lead compounds (đúng Bảng 4.2 báo cáo)
    final_top_n: int = 5
    expected_leads: Tuple[str, ...] = ("Rigosertib", "Volasertib", "BI 2536",
                                       "Barasertib", "Alisertib")
    benchmark_cell_lines: Tuple[str, ...] = ("HepG2", "Huh7", "Hep3B")


@dataclass
class EvalConfig:
    """Các chỉ số đánh giá (đúng báo cáo & Bảng 4.1)."""
    classification_metrics: Tuple[str, ...] = ("Accuracy", "Precision",
                                               "Recall", "F1", "AUC-ROC",
                                               "AUC-PR")
    survival_metric: str = "C-index"
    ic50_metrics: Tuple[str, ...] = ("Concordance_Index", "RMSE_logIC50")
    link_prediction_metric: str = "AUC-ROC"
    baselines: Tuple[str, ...] = ("RandomForest", "SVM", "MLP", "GCN",
                                  "GAT_homogeneous", "MOGONET")


@dataclass
class Paths:
    data_dir: str = "./data"
    raw_dir: str = "./data/raw"
    processed_dir: str = "./data/processed"
    graph_dir: str = "./data/graph"
    checkpoint_dir: str = "./checkpoints"
    results_dir: str = "./results"
    figures_dir: str = "./results/figures"


@dataclass
class GlobalConfig:
    data: DataConfig = field(default_factory=DataConfig)
    graph: GraphConfig = field(default_factory=GraphConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    train: TrainConfig = field(default_factory=TrainConfig)
    biomarker: BiomarkerConfig = field(default_factory=BiomarkerConfig)
    drug: DrugScreeningConfig = field(default_factory=DrugScreeningConfig)
    eval: EvalConfig = field(default_factory=EvalConfig)
    paths: Paths = field(default_factory=Paths)
    project_name: str = "HCC-GNN-MultiOmics"
    github_repo: str = "https://github.com/nguyendangphuc2012qb/HCC-GNN-MultiOmics.git"
    random_seed: int = 42


def get_config() -> GlobalConfig:
    """Trả về đối tượng cấu hình toàn cục (singleton dùng chung)."""
    return GlobalConfig()
