# -*- coding: utf-8 -*-
"""
HCC-GNN-MultiOmics
==================
Mã nguồn phục vụ báo cáo nghiên cứu:
"Ứng dụng mạng nơ-ron đồ thị (GNN) phân tích dữ liệu đa omics (multi-omics)
 nhằm phát hiện dấu sinh học (biomarkers) và sàng lọc, kiểm chứng thực nghiệm
 thuốc cho ung thư biểu mô tế bào gan (HCC)."

Cấu trúc module:
  config.py          — Cấu hình tập trung (siêu tham số, trọng số λ, ngưỡng)
  data_loader.py     — Giải pháp 1: Tải & tiền xử lý đa omics (D1–D6)
  graph_builder.py   — Giải pháp 2a: Xây dựng đồ thị dị thể (5 nút, 7 cạnh)
  models.py          — Giải pháp 2b: GAT/HAN + đầu đa nhiệm + hàm mất mát
  trainer.py         — Huấn luyện: Adam, cosine annealing, 5-fold×5-repeat CV
  evaluation.py      — Chỉ số đánh giá + baseline + Bảng 4.1 tham chiếu
  biomarker.py       — Giải pháp 3: Xếp hạng biomarker (Score tổng hợp), KM, Cox
  drug_screening.py  — Giải pháp 4: Sàng lọc thuốc 5 bước + Top 5 leads (Bảng 4.2)
  visualization.py   — Hình vẽ cho báo cáo (Hình 4.1–4.3, KM, attention heatmap)
  main.py            — Pipeline chạy end-to-end
"""
__version__ = "1.0.0"
__author__ = "Nhóm nghiên cứu HCC-GNN-MultiOmics"
