# -*- coding: utf-8 -*-
"""
models.py
=========
GIẢI PHÁP 2 (phần b) — Kiến trúc mô hình: HAN + GAT trên đồ thị dị thể.

Công thức GAT (đúng báo cáo):
  e_ij = LeakyReLU( a^T · [ W h_i || W h_j ] )          # điểm số chú ý
  α_ij = softmax_j( e_ij )                                # hệ số chú ý ∈ [0,1]
  h'_i = σ( Σ_j α_ij · W h_j )                            # cập nhật trạng thái nút
  multi-head: z_i = ||_{k=1..K} h'^{(k)}_i  (concat) hoặc trung bình ở lớp cuối

Hàm mất mát đa nhiệm (đúng báo cáo, λ1=1, λ2=1, λ3=0.5, λ4=1e-4, λ5=0.1):
  L_total = λ1·L_cls + λ2·L_reg + λ3·L_link + λ4·||Θ||₂² + λ5·L_recon

5 đầu ra đa nhiệm:
  (1) L_cls  : phân lớp khối u/bình thường (CrossEntropy)  -> nút patient
  (2) L_reg  : tiên lượng sống còn Cox (negative partial log-likelihood)
  (3) L_link : dự đoán liên kết thuốc–đích/thuốc–bệnh (BCE, negative sampling)
  (4) L2     : regularization trọng số
  (5) L_recon: tái tạo đặc trưng đa omics (MSE, auto-encoder regularization)
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GATConv, HANConv
from torch_geometric.data import HeteroData
from typing import Dict, Tuple, Optional

from .config import GlobalConfig


# ---------------------------------------------------------------------------
# 1. Lớp GAT thủ công (minh họa công thức, dùng cho đồ thị đồng nhất PPI)
# ---------------------------------------------------------------------------
class GraphAttentionLayer(nn.Module):
    """Một lớp chú ý đồ thị (GAT) — triển khai đúng công thức báo cáo."""

    def __init__(self, in_dim: int, out_dim: int,
                 negative_slope: float = 0.2, dropout: float = 0.3):
        super().__init__()
        self.W = nn.Linear(in_dim, out_dim, bias=False)
        # vector tham số a ∈ R^{2·out_dim} cho điểm số chú ý
        self.a = nn.Parameter(torch.empty(2 * out_dim, 1))
        nn.init.xavier_uniform_(self.a.data)
        self.leaky_relu = nn.LeakyReLU(negative_slope)
        self.dropout = nn.Dropout(dropout)

    def forward(self, h: torch.Tensor,
                edge_index: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """Trả về embedding mới + ma trận hệ số chú ý α (dùng xếp hạng biomarker)."""
        Wh = self.W(h)                                  # (N, out_dim)
        src, dst = edge_index                           # cạnh (j -> i)
        # e_ij = LeakyReLU( a^T · [ W h_i || W h_j ] )
        concat = torch.cat([Wh[dst], Wh[src]], dim=1)   # (E, 2·out_dim)
        e = self.leaky_relu(concat @ self.a).squeeze(-1)  # (E,)
        # α_ij = softmax theo các nút lân cận j của i
        alpha = self._softmax_by_node(e, dst, num_nodes=h.size(0))
        alpha = self.dropout(alpha)
        # h'_i = σ( Σ_j α_ij · W h_j )
        agg = torch.zeros_like(Wh)
        agg.index_add_(0, dst, alpha.unsqueeze(-1) * Wh[src])
        return F.elu(agg), alpha

    @staticmethod
    def _softmax_by_node(e: torch.Tensor, dst: torch.Tensor,
                         num_nodes: int) -> torch.Tensor:
        e_max = torch.zeros(num_nodes, device=e.device).scatter_reduce(
            0, dst, e, reduce="amax", include_self=False)
        e = e - e_max[dst]
        exp_e = torch.exp(e)
        sum_exp = torch.zeros(num_nodes, device=e.device).scatter_add_(
            0, dst, exp_e)
        return exp_e / (sum_exp[dst] + 1e-16)


class MultiHeadGAT(nn.Module):
    """Multi-head GAT: concat K đầu ở lớp giữa, trung bình ở lớp cuối."""

    def __init__(self, in_dim: int, hidden_dim: int, out_dim: int,
                 num_heads: int = 8, num_layers: int = 2, dropout: float = 0.3):
        super().__init__()
        self.layers = nn.ModuleList()
        dims = [in_dim] + [hidden_dim] * (num_layers - 1) + [out_dim]
        for i in range(num_layers):
            heads = num_heads if i < num_layers - 1 else 1
            self.layers.append(nn.ModuleList([
                GraphAttentionLayer(dims[i], dims[i + 1], dropout=dropout)
                for _ in range(heads)
            ]))
        self.heads_last = num_heads if num_layers == 1 else 1

    def forward(self, x, edge_index):
        alphas = []
        for li, heads in enumerate(self.layers):
            outs = []
            for head in heads:
                h, a = head(x, edge_index)
                outs.append(h); alphas.append(a)
            x = torch.cat(outs, dim=-1) if len(outs) > 1 else outs[0]
            if li < len(self.layers) - 1:
                x = F.elu(x)
        return x, alphas


# ---------------------------------------------------------------------------
# 2. Mô hình chính: HAN (đồ thị dị thể) + multi-task decoder
# ---------------------------------------------------------------------------
class HANMultiOmics(nn.Module):
    """Heterogeneous Graph Attention Network (HAN) + đầu ra đa nhiệm.

    HAN gồm 2 mức chú ý:
      • Node-level attention (GAT theo từng meta-path)  -> học embedding theo cạnh
      • Semantic-level attention                        -> hợp nhất các meta-path
    """

    def __init__(self, cfg: GlobalConfig, metadata: Tuple):
        super().__init__()
        self.cfg = cfg
        m = cfg.model
        # HANConv của PyG xử lý đồ thị dị thể với nhiều loại cạnh
        self.han = HANConv(
            in_channels=-1,                  # suy luận từ kích thước x
            out_channels=m.hidden_dim,
            metadata=metadata,
            heads=m.num_heads,
            dropout=m.dropout,
        )
        # Đầu đa nhiệm (heads)
        self.cls_head = nn.Sequential(
            nn.Linear(m.hidden_dim, m.hidden_dim // 2), nn.ReLU(),
            nn.Dropout(m.dropout),
            nn.Linear(m.hidden_dim // 2, m.num_classes))
        self.surv_head = nn.Sequential(
            nn.Linear(m.hidden_dim, m.hidden_dim // 2), nn.ReLU(),
            nn.Linear(m.hidden_dim // 2, m.survival_output))   # Cox risk score
        self.ic50_head = nn.Sequential(
            nn.Linear(m.hidden_dim * 2, m.hidden_dim), nn.ReLU(),
            nn.Linear(m.hidden_dim, m.ic50_output))             # log IC50
        self.recon_head = nn.Linear(m.hidden_dim, m.recon_output)
        # Link prediction decoder: bilinear (dot-product sau projection)
        self.link_proj = nn.Linear(m.hidden_dim, m.hidden_dim)

    def encode(self, data: HeteroData) -> Dict[str, torch.Tensor]:
        """Mã hóa đồ thị -> embedding z cho mọi loại nút."""
        x_dict = {nt: data[nt].x for nt in data.node_types}
        edge_index_dict = {et: data[et].edge_index for et in data.edge_types}
        z_dict = self.han(x_dict, edge_index_dict)
        return z_dict

    # --- Các đầu dự đoán ---
    def predict_class(self, z_patient: torch.Tensor) -> torch.Tensor:
        return self.cls_head(z_patient)

    def predict_risk(self, z_patient: torch.Tensor) -> torch.Tensor:
        return self.surv_head(z_patient).squeeze(-1)     # Cox hazard score

    def predict_ic50(self, z_drug: torch.Tensor,
                     z_gene: torch.Tensor) -> torch.Tensor:
        pair = torch.cat([z_drug, z_gene], dim=-1)
        return self.ic50_head(pair).squeeze(-1)          # log IC50

    def predict_link(self, z_u: torch.Tensor,
                     z_v: torch.Tensor) -> torch.Tensor:
        """Điểm số liên kết s(u,v) = σ( <W z_u, W z_v> ) — decoder link prediction."""
        u = self.link_proj(z_u); v = self.link_proj(z_v)
        return torch.sigmoid((u * v).sum(dim=-1))

    def reconstruct(self, z: torch.Tensor) -> torch.Tensor:
        return self.recon_head(z)

    def forward(self, data: HeteroData):
        z_dict = self.encode(data)
        return z_dict


# ---------------------------------------------------------------------------
# 3. Hàm mất mát đa nhiệm (đúng công thức & trọng số báo cáo)
# ---------------------------------------------------------------------------
class MultiTaskLoss(nn.Module):
    """L_total = λ1·L_cls + λ2·L_reg(Cox) + λ3·L_link + λ4·||Θ||₂² + λ5·L_recon"""

    def __init__(self, cfg: GlobalConfig):
        super().__init__()
        self.cfg = cfg.model

    @staticmethod
    def cox_partial_likelihood(risk: torch.Tensor, time: torch.Tensor,
                               event: torch.Tensor) -> torch.Tensor:
        """Negative partial log-likelihood của mô hình Cox (tiên lượng sống còn)."""
        order = torch.argsort(time, descending=True)
        risk, event = risk[order], event[order]
        log_cumsum_exp = torch.logcumsumexp(risk, dim=0)
        uncensored = event == 1
        if uncensored.sum() == 0:
            return torch.tensor(0.0, device=risk.device)
        nll = -(risk[uncensored] - log_cumsum_exp[uncensored]).mean()
        return nll

    def forward(self, model: HANMultiOmics, z_dict: Dict[str, torch.Tensor],
                data: HeteroData, link_pred: Optional[Tuple] = None,
                recon_target: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
        m = self.cfg
        zp = z_dict["patient"]

        # (1) L_cls: phân lớp khối u / bình thường
        logits = model.predict_class(zp)
        l_cls = F.cross_entropy(logits, data["patient"].y_cls)

        # (2) L_reg: Cox survival regression
        risk = model.predict_risk(zp)
        l_reg = self.cox_partial_likelihood(risk, data["patient"].time,
                                            data["patient"].event)

        # (3) L_link: dự đoán liên kết (BCE với negative sampling)
        l_link = torch.tensor(0.0, device=zp.device)
        if link_pred is not None:
            pos_score, neg_score = link_pred
            l_link = (F.binary_cross_entropy(pos_score, torch.ones_like(pos_score))
                      + F.binary_cross_entropy(neg_score, torch.zeros_like(neg_score))) / 2

        # (4) L2 regularization
        l_l2 = sum((p ** 2).sum() for p in model.parameters())

        # (5) L_recon: tái tạo đặc trưng đa omics
        l_recon = torch.tensor(0.0, device=zp.device)
        if recon_target is not None:
            recon = model.reconstruct(zp)
            l_recon = F.mse_loss(recon, recon_target)

        total = (m.lambda_cls * l_cls + m.lambda_reg * l_reg
                 + m.lambda_link * l_link + m.lambda_l2 * l_l2
                 + m.lambda_recon * l_recon)
        return {"total": total, "cls": l_cls, "reg": l_reg,
                "link": l_link, "l2": l_l2, "recon": l_recon}
