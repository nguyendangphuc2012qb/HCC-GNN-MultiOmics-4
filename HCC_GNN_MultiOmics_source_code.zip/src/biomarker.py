# -*- coding: utf-8 -*-
"""
biomarker.py
============
GIẢI PHÁP 3 — Phát hiện & xếp hạng dấu sinh học (biomarker).

Nguyên lý (theo báo cáo): phân tử nào mô hình dựa vào nhiều nhất (attention
weight cao), nằm ở vị trí then chốt của mạng (hub/bottleneck), có giá trị
tiên lượng (Cox HR có ý nghĩa) và liên quan pathway bệnh -> là biomarker.

Thang điểm tổng hợp (đúng công thức báo cáo):
  Biomarker Score = 0.35·(attention weight chuẩn hóa)
                  + 0.25·(độ trung tâm mạng: degree/betweenness/closeness chuẩn hóa)
                  + 0.25·(giá trị tiên lượng: |log HR|, -log10 p Cox)
                  + 0.15·(mức biểu hiện sai khác: |log2FC|, -log10 FDR)

Xác nhận & giải thích:
  (1) Xác nhận độc lập trên GEO/ICGC (giữ hướng HR, p<0.05)
  (2) Kaplan–Meier (chia high/low theo trung vị, log-rank test)
  (3) Cox đa biến điều chỉnh tuổi, giới tính, giai đoạn, xơ gan, HBV/HCV
  (4) Phân tích làm giàu pathway (GO/KEGG/GSEA) — trục PLK1–CDC20–BUB1 (G2/M)
"""
import numpy as np
import pandas as pd
import networkx as nx
from typing import Dict, List, Tuple
from lifelines import KaplanMeierFitter, CoxPHFitter
from lifelines.statistics import logrank_test
from scipy.stats import zscore

from .config import GlobalConfig


def normalize(series: pd.Series) -> pd.Series:
    """Chuẩn hóa min-max về [0,1] để tổng hợp thang điểm."""
    s = series.astype(float)
    if s.max() == s.min():
        return pd.Series(0.5, index=s.index)
    return (s - s.min()) / (s.max() - s.min())


def attention_score(alpha_list: List[np.ndarray], gene_names: List[str],
                    edge_src: np.ndarray) -> pd.Series:
    """Tổng hợp hệ số chú ý α_ij theo nút nguồn (gen) -> điểm attention trung bình."""
    gene_attn = pd.Series(0.0, index=gene_names)
    counts = pd.Series(0, index=gene_names)
    for alpha in alpha_list:
        for a, src_idx in zip(alpha, edge_src):
            if src_idx < len(gene_names):
                gene_attn.iloc[src_idx] += float(a)
                counts.iloc[src_idx] += 1
    gene_attn = gene_attn / counts.clip(lower=1)
    return gene_attn.fillna(0)


def network_centrality_scores(edge_list: List[Tuple[int, int]],
                              gene_names: List[str]) -> pd.DataFrame:
    """Tính degree, betweenness, closeness centrality trên mạng PPI."""
    G = nx.Graph()
    G.add_nodes_from(range(len(gene_names)))
    G.add_edges_from([(u, v) for u, v in edge_list if u < len(gene_names) and v < len(gene_names)])
    scores = pd.DataFrame(index=gene_names)
    scores["degree"] = pd.Series(nx.degree_centrality(G)).reindex(range(len(gene_names))).values
    scores["betweenness"] = pd.Series(nx.betweenness_centrality(G, k=min(100, len(gene_names)))) \
        .reindex(range(len(gene_names))).fillna(0).values
    scores["closeness"] = pd.Series(nx.closeness_centrality(G)) \
        .reindex(range(len(gene_names))).fillna(0).values
    return scores.fillna(0)


def prognostic_score(expression: pd.DataFrame, clinical: pd.DataFrame,
                     gene_names: List[str]) -> pd.Series:
    """|log HR| và -log10(p) từ Cox đơn biến cho từng gen -> điểm tiên lượng."""
    rows = []
    df = expression.copy()
    df["time"] = clinical["time"].values; df["event"] = clinical["event"].values
    for g in gene_names:
        if g not in expression.columns:
            rows.append({"gene": g, "logHR": 0, "neglog10p": 0}); continue
        try:
            cph = CoxPHFitter()
            cph.fit(df[["time", "event", g]].rename(columns={g: "expr"}),
                    duration_col="time", event_col="event")
            hr = cph.hazard_ratios_["expr"]
            p = cph.summary.loc["expr", "p"]
            rows.append({"gene": g, "logHR": abs(np.log(hr)),
                         "neglog10p": -np.log10(max(p, 1e-300))})
        except Exception:
            rows.append({"gene": g, "logHR": 0, "neglog10p": 0})
    res = pd.DataFrame(rows).set_index("gene")
    return normalize(res["logHR"]) * 0.5 + normalize(res["neglog10p"]) * 0.5


def deg_score(log2fc: pd.Series, fdr: pd.Series) -> pd.Series:
    """Điểm biểu hiện sai khác: |log2FC| và -log10(FDR)."""
    return normalize(log2fc.abs()) * 0.5 + normalize(-np.log10(fdr.clip(lower=1e-300))) * 0.5


def rank_biomarkers(attn: pd.Series, centrality: pd.DataFrame,
                    prog: pd.Series, deg: pd.Series,
                    cfg: GlobalConfig) -> pd.DataFrame:
    """Tính Biomarker Score tổng hợp & xếp hạng Top-N (đúng trọng số báo cáo)."""
    b = cfg.biomarker
    df = pd.DataFrame(index=attn.index)
    df["attention"] = normalize(attn)
    df["centrality"] = normalize(centrality.mean(axis=1))
    df["prognostic"] = normalize(prog.reindex(df.index).fillna(0))
    df["deg"] = normalize(deg.reindex(df.index).fillna(0))
    df["Biomarker_Score"] = (b.weight_attention * df["attention"]
                             + b.weight_centrality * df["centrality"]
                             + b.weight_prognostic * df["prognostic"]
                             + b.weight_deg * df["deg"])
    df = df.sort_values("Biomarker_Score", ascending=False)
    df["Rank"] = range(1, len(df) + 1)
    return df.head(b.top_n_biomarkers)


def kaplan_meier_analysis(expression: pd.Series, clinical: pd.DataFrame,
                          gene: str) -> Dict:
    """Phân tích sống còn Kaplan–Meier: chia high/low theo trung vị, log-rank."""
    cutoff = expression.median()
    high = expression >= cutoff
    T, E = clinical["time"], clinical["event"]
    kmf_high = KaplanMeierFitter(); kmf_high.fit(T[high], E[high], label="High")
    kmf_low = KaplanMeierFitter();  kmf_low.fit(T[~high], E[~high], label="Low")
    lr = logrank_test(T[high], T[~high], E[high], E[~high])
    return {"gene": gene, "cutoff": cutoff, "logrank_p": lr.p_value,
            "median_survival_high": kmf_high.median_survival_time_,
            "median_survival_low": kmf_low.median_survival_time_}


def multivariate_cox(expression: pd.DataFrame, clinical: pd.DataFrame,
                     genes: List[str], covariates: List[str]) -> pd.DataFrame:
    """Cox đa biến điều chỉnh covariates (tuổi, giới tính, giai đoạn, xơ gan, HBV/HCV)."""
    df = expression[genes].copy()
    for c in covariates:
        if c in clinical.columns:
            df[c] = clinical[c].values
    df["time"] = clinical["time"].values; df["event"] = clinical["event"].values
    cph = CoxPHFitter()
    cph.fit(df, duration_col="time", event_col="event")
    return cph.summary[["exp(coef)", "p", "lower 0.95", "upper 0.95"]]


# Trục biomarker cốt lõi dự kiến (theo báo cáo mục 4.2)
EXPECTED_CORE_BIOMARKERS = ["PLK1", "CDC20", "BUB1", "AURKA", "AURKB", "CCNB1"]
KNOWN_DRIVER_GENES = ["TP53", "CTNNB1", "TERT", "MYC", "AKT1", "VEGFA"]  # kiểm định mô hình
