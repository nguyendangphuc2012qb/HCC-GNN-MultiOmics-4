# HCC-GNN-MultiOmics

**Ứng dụng mạng nơ-ron đồ thị dị thể (HAN+GAT) phân tích dữ liệu đa omics nhằm phát hiện dấu sinh học (biomarkers) và sàng lọc thuốc cho ung thư biểu mô tế bào gan (HCC).**

Mã nguồn phục vụ báo cáo nghiên cứu khoa học. Toàn bộ pipeline được thiết kế theo 4 giải pháp:

| Giải pháp | Nội dung | Module chính |
|---|---|---|
| 1 | Tích hợp đa omics (D1–D6): QC, chuẩn hóa, KNN-impute, ComBat, lọc DEG, PCA | `src/data_loader.py` |
| 2 | Đồ thị dị thể (5 nút, 7 cạnh) + mô hình HAN+GAT đa nhiệm | `src/graph_builder.py`, `src/models.py`, `src/trainer.py` |
| 3 | Phát hiện & xếp hạng biomarker (attention + centrality + Cox + DEG) | `src/biomarker.py` |
| 4 | Sàng lọc thuốc 5 bước + thẩm định y văn (Top 5 leads) | `src/drug_screening.py` |

## Cài đặt

```bash
pip install -r requirements.txt
# torch-geometric cần CUDA phù hợp; xem hướng dẫn tại https://pytorch-geometric.readthedocs.io
```

## Chạy nhanh (demo với dữ liệu mô phỏng)

```bash
python -m src.main --synthetic
```

Kết quả được lưu tại `./results/`:
- `baselines.csv` — RF/SVM/MLP baseline
- `table4_1_model_comparison.csv` — Bảng 4.1 so sánh 6 mô hình
- `top_biomarkers.csv` — Top-20 biomarker xếp hạng
- `table4_2_lead_compounds.csv` — Bảng 4.2 Top 5 lead compounds
- `figures/` — Hình 4.1, 4.2, 4.3, Kaplan–Meier

## Chạy với dữ liệu thật

1. Tải dữ liệu từ TCGA-LIHC (GDC Portal), ICGC-LIRI-JP, GEO (GSE14520, GSE76427), CPTAC-HCC.
2. Đặt tại `./data/raw/` theo định dạng TSV (mỗi lớp omics một file, index = patient barcode).
3. Chạy: `python -m src.main --no-synthetic --data_dir ./data`

## Siêu tham số chính (đúng báo cáo)

- **Hàm mất mát đa nhiệm**: `L = 1.0·L_cls + 1.0·L_reg + 0.5·L_link + 1e-4·L2 + 0.1·L_recon`
- **Optimizer**: Adam (lr=1e-3), cosine annealing, 500 epoch, early stopping (patience=50)
- **Đánh giá**: 5-fold CV × 5 lần lặp (seed khác nhau), báo cáo mean ± SD
- **Biomarker Score**: `0.35·attention + 0.25·centrality + 0.25·prognostic + 0.15·DEG`
- **Mục tiêu hiệu năng**: AUC-ROC ≥ 0.89, C-index ≥ 0.72, CI IC50 ≥ 0.80

## Kết quả dự kiến (tham chiếu Bảng 4.1 & 4.2)

- Mô hình đề xuất HAN+GAT: AUC-ROC = 0.912, C-index = 0.720, CI IC50 = 0.845
- Top 5 leads: **Rigosertib (0.942)**, Volasertib (0.913), BI 2536 (0.881), Barasertib (0.854), Alisertib (0.817) — nhắm trục phân bào G2/M (PLK1 / Aurora A/B)
- Best Lead (Rigosertib): giảm 77.6% khối u in vivo (so với 54.1% của Sorafenib)

Repo: `https://github.com/nguyendangphuc2012qb/HCC-GNN-MultiOmics.git`
