# -*- coding: utf-8 -*-
"""
evaluation.py
=============
Đánh giá mô hình & so sánh với baseline (đúng Bảng 4.1 báo cáo).

Chỉ số đánh giá:
  • Phân lớp: Accuracy, Precision, Recall, F1, AUC-ROC, AUC-PR
  • Tiên lượng sống còn: C-index (Concordance Index)
  • Dự đoán IC50: Concordance Index + RMSE(log IC50)
  • Link prediction: AUC-ROC

Baseline so sánh (đúng Bảng 4.1):
  1. Random Forest   — đơn omics (mRNA)
  2. SVM / MLP       — đơn omics (mRNA)
  3. GCN đồng nhất   — mRNA + PPI
  4. GAT đồng nhất   — mRNA + PPI
  5. MOGONET         — 3 omics (mRNA, miRNA, methylation)
  6. HAN+GAT (đề xuất) — 4 omics + PPI + thuốc–đích–bệnh
"""
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score, average_precision_score,
                             mean_squared_error)
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import cross_val_predict, StratifiedKFold
from lifelines.utils import concordance_index

from .config import GlobalConfig

# Kết quả tham chiếu từ Bảng 4.1 (dùng để benchmark / đối chiếu)
REFERENCE_TABLE_4_1 = pd.DataFrame([
    ["Random Forest (baseline)", "Đơn omics (mRNA)", 0.701, 0.612, 0.612, 0.789],
    ["MLP (baseline)", "Đơn omics (mRNA)", 0.756, 0.658, 0.658, 0.712],
    ["GCN (đồng nhất, chỉ PPI)", "mRNA + PPI", 0.802, 0.660, 0.712, 0.612],
    ["GAT (đồng nhất, chỉ PPI)", "mRNA + PPI", 0.843, 0.672, 0.772, 0.563],
    ["MOGONET (GCN đa đầu)", "3 omics", 0.875, 0.690, 0.805, 0.498],
    ["HAN+GAT (đề xuất)", "4 omics + PPI + drug-target", 0.912, 0.720, 0.845, 0.421],
], columns=["Mô hình", "Đầu vào", "AUC-ROC", "C-index", "CI_IC50", "RMSE_logIC50"])


# ---------------------------------------------------------------------------
# Các chỉ số đánh giá
# ---------------------------------------------------------------------------
def classification_metrics(y_true: np.ndarray, y_prob: np.ndarray,
                           threshold: float = 0.5) -> Dict[str, float]:
    y_pred = (y_prob >= threshold).astype(int)
    return {
        "Accuracy":  accuracy_score(y_true, y_pred),
        "Precision": precision_score(y_true, y_pred, zero_division=0),
        "Recall":    recall_score(y_true, y_pred, zero_division=0),
        "F1":        f1_score(y_true, y_pred, zero_division=0),
        "AUC-ROC":   roc_auc_score(y_true, y_prob) if len(set(y_true)) > 1 else np.nan,
        "AUC-PR":    average_precision_score(y_true, y_prob),
    }


def survival_cindex(risk_score: np.ndarray, time: np.ndarray,
                    event: np.ndarray) -> float:
    """C-index: tỷ lệ cặp bệnh nhân mà risk_score xếp hạng đúng với thời gian sống."""
    return concordance_index(time, -risk_score, event)


def ic50_metrics(pred_log_ic50: np.ndarray,
                 true_log_ic50: np.ndarray) -> Dict[str, float]:
    ci = concordance_index(-true_log_ic50, -pred_log_ic50)  # IC50 thấp = tốt
    rmse = np.sqrt(mean_squared_error(true_log_ic50, pred_log_ic50))
    return {"Concordance_Index": ci, "RMSE_logIC50": rmse}


def link_prediction_auc(pos_scores: np.ndarray,
                        neg_scores: np.ndarray) -> float:
    y = np.concatenate([np.ones_like(pos_scores), np.zeros_like(neg_scores)])
    s = np.concatenate([pos_scores, neg_scores])
    return roc_auc_score(y, s)


# ---------------------------------------------------------------------------
# Baseline học máy truyền thống (RF / SVM / MLP) trên đơn omics
# ---------------------------------------------------------------------------
def run_traditional_baselines(X: np.ndarray, y: np.ndarray,
                              cfg: GlobalConfig) -> pd.DataFrame:
    """Chạy RF, SVM, MLP với 5-fold CV, trả về AUC-ROC trung bình."""
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=cfg.random_seed)
    models = {
        "RandomForest": RandomForestClassifier(n_estimators=500, random_state=cfg.random_seed, n_jobs=-1),
        "SVM":          SVC(probability=True, random_state=cfg.random_seed),
        "MLP":          MLPClassifier(hidden_layer_sizes=(256, 128), max_iter=500,
                                      random_state=cfg.random_seed),
    }
    rows = []
    for name, clf in models.items():
        prob = cross_val_predict(clf, X, y, cv=cv, method="predict_proba")[:, 1]
        m = classification_metrics(y, prob)
        rows.append({"Mô hình": name, "AUC-ROC": round(m["AUC-ROC"], 3),
                     "F1": round(m["F1"], 3), "Accuracy": round(m["Accuracy"], 3)})
    return pd.DataFrame(rows)


def ablation_by_omics_layers(X_dict: Dict[str, np.ndarray], y: np.ndarray,
                             cfg: GlobalConfig) -> pd.DataFrame:
    """Phân tích bỏ một (ablation): thêm từng lớp omics, đo AUC-ROC.

    Theo báo cáo 4.1: AUC tăng 0.72 (chỉ mRNA) -> 0.91 (đủ 4 lớp).
    """
    order = ["mrna", "mirna", "genomics", "proteomics", "metabolomics"]
    rows, accumulated = [], []
    for layer in order:
        if layer in X_dict:
            accumulated.append(X_dict[layer])
            X = np.hstack(accumulated)
            clf = RandomForestClassifier(n_estimators=300, random_state=cfg.random_seed, n_jobs=-1)
            cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=cfg.random_seed)
            prob = cross_val_predict(clf, X, y, cv=cv, method="predict_proba")[:, 1]
            rows.append({"Tích lũy omics": " + ".join(accumulated),
                         "AUC-ROC": round(roc_auc_score(y, prob), 3)})
    return pd.DataFrame(rows)


def compare_with_reference(results: Dict[str, float]) -> pd.DataFrame:
    """Đối chiếu kết quả thực nghiệm với Bảng 4.1 tham chiếu."""
    df = REFERENCE_TABLE_4_1.copy()
    df["Ghi chú"] = ""
    df.loc[df["Mô hình"].str.contains("đề xuất"), "Ghi chú"] = \
        f"Thực nghiệm: AUC={results.get('auc', float('nan')):.3f}"
    return df
